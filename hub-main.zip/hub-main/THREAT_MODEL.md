# THREAT_MODEL.md — Hub

## Assets
- User chat history (encrypted in Drive appDataFolder)
- API keys (Worker secrets only)
- OAuth tokens / Hub JWT
- Approval queue / agent side effects
- Model registry / promotion state

## Mitigations
| Threat | Control |
|--------|---------|
| Key exfiltration | Keys only in Worker secrets |
| Prompt injection → side effect | Approval queue required |
| Agent self-modification | applyChange blocks protected prefixes + prototype pollution |
| Ciphertext swap | AES-GCM AAD binds record ID |
| Egress SSRF | Allowlist + https-only + manual redirect re-validation |
| Sensitive → may_train | isSensitive + Private mode + router |
| Free → paid flip | classifyCost + demoteNonFree + :free suffix |
| Token theft | 1h JWT, ALLOWED_EMAIL, PKCE |
| Kill switch | Config flag on every request |
