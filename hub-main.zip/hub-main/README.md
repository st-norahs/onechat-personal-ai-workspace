# Hub

Private single-user multi-model AI assistant. **Zero cost.**

Repo: https://github.com/st-norahs/hub

## Status (phases 0–7)

| Phase | Deliverable |
|-------|-------------|
| 0 | ZERO_COST.md — verified free limits |
| 1 | Monorepo, OAuth PKCE, JWT allowlist, QuotaDO, PWA, client crypto |
| 2 | Providers (Gemini/Groq/OpenRouter/CF/Local), `/chat/stream`, ChatShell |
| 3 | Compare + Council fan-out + synthesizer |
| 4 | Approval queue + D1 audit log |
| 5 | Model registry, leaderboard, quotas, promotion log |
| 6 | THREAT_MODEL, egress allowlist, kill switch, CSP |
| 7 | GitHub Actions CI, `scripts/doctor.mjs` |

Core guards: **30/30 tests passing** (`packages/shared`).

## Quick start

```bash
git clone https://github.com/st-norahs/hub.git && cd hub
# Ensure core.mjs + core.test.mjs are in packages/shared/src/
pnpm install
pnpm --filter @hub/shared test   # 30 pass

cp .env.example .dev.vars
# Fill: JWT_SECRET, ALLOWED_EMAIL, GOOGLE_CLIENT_*, GROQ_API_KEY (recommended first)

pnpm --filter @hub/api run dev   # :8787
pnpm --filter @hub/web run dev   # :5173
```

Open http://localhost:5173 → Google sign-in → passphrase → chat.
Buttons: **Model Lab**, **Compare**.

## API surface

| Route | Purpose |
|-------|--------|
| `POST /auth/token` | OAuth code exchange |
| `POST /chat/stream` | SSE chat (free providers) |
| `POST /council/compare` | Side-by-side free models |
| `POST /council/council` | Fan-out + synthesizer |
| `POST /approvals/queue` | Queue side-effect for approval |
| `GET /approvals/pending` | List pending |
| `POST /approvals/:id/decide` | approve/reject |
| `GET /models/registry` | Model catalog |
| `GET /models/leaderboard` | Per-task ranking |
| `GET /models/quotas` | Remaining quota meters |

## Manual steps (only you)

1. Google Cloud OAuth consent → **In production**
2. Redirect URIs: `http://localhost:5173/auth/callback` + Pages URL
3. Free keys: Groq, Gemini AI Studio, OpenRouter, Cloudflare token
4. `wrangler d1 create hub-audit` → paste ID in `wrangler.toml`
5. `wrangler secret put` each required secret → `pnpm deploy`

## Docs
- ZERO_COST.md · ARCHITECTURE.md · THREAT_MODEL.md · MODEL_LAYER.md
