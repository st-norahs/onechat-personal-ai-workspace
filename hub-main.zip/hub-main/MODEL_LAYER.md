# MODEL_LAYER.md

Registry seeded in Worker; D1 cache; router in packages/shared.
Promotion: candidate → shadow → canary5 → canary25 → active (owner approval).
Scouts run in GitHub Actions only; proposals never auto-integrate.
Agents cannot modify permissions, allowlist, quotas, killSwitch, guardrails, autoPromote, tierB.
