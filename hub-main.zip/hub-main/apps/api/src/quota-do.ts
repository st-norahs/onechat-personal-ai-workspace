import { DurableObject } from 'cloudflare:workers';

interface Ev {
  t: number;
  tokens: number;
}

export class QuotaDO extends DurableObject {
  private async load(key: string): Promise<Ev[]> {
    const row = await this.ctx.storage.sql
      .exec('SELECT data FROM events WHERE key = ?', key)
      .toArray();
    if (!row.length) return [];
    try {
      return JSON.parse(row[0].data as string) as Ev[];
    } catch {
      return [];
    }
  }

  private async save(key: string, events: Ev[]) {
    await this.ctx.storage.sql.exec(
      `CREATE TABLE IF NOT EXISTS events (key TEXT PRIMARY KEY, data TEXT);
       INSERT OR REPLACE INTO events (key, data) VALUES (?, ?)`,
      key,
      JSON.stringify(events),
    );
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    if (path === '/record' && request.method === 'POST') {
      const { key, tokens = 0 } = await request.json() as { key: string; tokens?: number };
      const events = await this.load(key);
      events.push({ t: Date.now(), tokens });
      const cutoff = Date.now() - 86_400_000;
      const pruned = events.filter((e) => e.t > cutoff);
      await this.save(key, pruned);
      return Response.json({ ok: true, count: pruned.length });
    }

    if (path === '/usage' && request.method === 'GET') {
      const key = url.searchParams.get('key') || '';
      const windowMs = Number(url.searchParams.get('windowMs') || 86_400_000);
      const events = await this.load(key);
      const cutoff = Date.now() - windowMs;
      const arr = events.filter((e) => e.t > cutoff);
      return Response.json({
        requests: arr.length,
        tokens: arr.reduce((s, e) => s + e.tokens, 0),
      });
    }

    if (path === '/remaining' && request.method === 'POST') {
      const { key, quota } = await request.json() as {
        key: string;
        quota: { rpm?: number; rpd?: number; tpm?: number; tpd?: number };
      };
      const events = await this.load(key);
      const now = Date.now();
      const minute = events.filter((e) => e.t > now - 60_000);
      const day = events.filter((e) => e.t > now - 86_400_000);
      return Response.json({
        rpm: quota.rpm == null ? Infinity : quota.rpm - minute.length,
        rpd: quota.rpd == null ? Infinity : quota.rpd - day.length,
        tpm: quota.tpm == null ? Infinity : quota.tpm - minute.reduce((s, e) => s + e.tokens, 0),
        tpd: quota.tpd == null ? Infinity : quota.tpd - day.reduce((s, e) => s + e.tokens, 0),
      });
    }

    return new Response('not found', { status: 404 });
  }
}
