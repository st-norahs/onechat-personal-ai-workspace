import { Hono } from 'hono';
import { z } from 'zod';

const TokenExchange = z.object({
  code: z.string().min(1),
  code_verifier: z.string().min(43),
  redirect_uri: z.string().url(),
});

export const authRoutes = new Hono();

authRoutes.get('/config', (c) => {
  return c.json({
    client_id: c.env.GOOGLE_CLIENT_ID,
    scopes: [
      'openid',
      'email',
      'https://www.googleapis.com/auth/drive.appdata',
    ],
  });
});

authRoutes.post('/token', async (c) => {
  const body = await c.req.json().catch(() => null);
  const parsed = TokenExchange.safeParse(body);
  if (!parsed.success) {
    return c.json({ error: 'invalid request' }, 400);
  }

  const { code, code_verifier, redirect_uri } = parsed.data;
  const clientId = c.env.GOOGLE_CLIENT_ID;
  const clientSecret = c.env.GOOGLE_CLIENT_SECRET;
  const allowed = (c.env.ALLOWED_EMAIL || '').toLowerCase();

  if (!clientId || !clientSecret || !allowed) {
    return c.json({ error: 'auth not configured' }, 503);
  }

  const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri,
      grant_type: 'authorization_code',
      code_verifier,
    }),
  });

  if (!tokenRes.ok) {
    const err = await tokenRes.text();
    console.error('token exchange failed', err);
    return c.json({ error: 'token exchange failed' }, 401);
  }

  const tokens = await tokenRes.json() as {
    access_token: string;
    refresh_token?: string;
    id_token?: string;
    expires_in: number;
  };

  const userRes = await fetch('https://openidconnect.googleapis.com/v1/userinfo', {
    headers: { Authorization: `Bearer ${tokens.access_token}` },
  });
  if (!userRes.ok) {
    return c.json({ error: 'userinfo failed' }, 401);
  }
  const user = await userRes.json() as { email?: string; sub?: string };
  const email = (user.email || '').toLowerCase();
  if (email !== allowed) {
    return c.json({ error: 'email not allowed' }, 403);
  }

  const jwtSecret = c.env.JWT_SECRET;
  if (!jwtSecret) {
    return c.json({ error: 'jwt not configured' }, 503);
  }

  const now = Math.floor(Date.now() / 1000);
  const payload = {
    sub: user.sub,
    email,
    iat: now,
    exp: now + 3600,
  };
  const header = { alg: 'HS256', typ: 'JWT' };
  const b64 = (obj: unknown) =>
    btoa(JSON.stringify(obj)).replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
  const unsigned = `${b64(header)}.${b64(payload)}`;
  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(jwtSecret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(unsigned));
  const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sig)))
    .replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
  const hubJwt = `${unsigned}.${sigB64}`;

  return c.json({
    hub_token: hubJwt,
    expires_in: 3600,
    google: {
      access_token: tokens.access_token,
      refresh_token: tokens.refresh_token,
      expires_in: tokens.expires_in,
    },
  });
});
