import { Hono } from 'hono';

export const healthRoutes = new Hono();

healthRoutes.get('/', (c) => c.json({
  status: 'ok',
  ts: Date.now(),
  free: true,
}));

healthRoutes.get('/ready', async (c) => {
  const hasQuota = !!c.env.QUOTA;
  const hasDb = !!c.env.DB;
  return c.json({
    ready: hasQuota && hasDb,
    bindings: { quota: hasQuota, db: hasDb },
  });
});
