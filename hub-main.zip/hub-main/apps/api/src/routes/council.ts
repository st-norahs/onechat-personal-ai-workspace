import { Hono } from 'hono';
import { streamSSE } from 'hono/streaming';

export const councilRoutes = new Hono();

type Msg = { role: string; content: string };

async function callProvider(
  env: Record<string, string | undefined>,
  provider: string,
  messages: Msg[],
): Promise<{ provider: string; model: string; text: string; error?: string }> {
  try {
    if (provider === 'groq' && env.GROQ_API_KEY) {
      const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: { Authorization: `Bearer ${env.GROQ_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'openai/gpt-oss-20b', messages, max_tokens: 1024, temperature: 0.5 }),
      });
      if (!res.ok) return { provider, model: 'gpt-oss-20b', text: '', error: await res.text() };
      const j = await res.json() as { choices?: Array<{ message?: { content?: string } }> };
      return { provider, model: 'openai/gpt-oss-20b', text: j.choices?.[0]?.message?.content || '' };
    }
    if (provider === 'gemini' && env.GEMINI_API_KEY) {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:generateContent?key=${env.GEMINI_API_KEY}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: messages.filter((m) => m.role !== 'system').map((m) => ({
              role: m.role === 'assistant' ? 'model' : 'user',
              parts: [{ text: m.content }],
            })),
            generationConfig: { maxOutputTokens: 1024 },
          }),
        },
      );
      if (!res.ok) return { provider, model: 'flash-lite', text: '', error: await res.text() };
      const j = await res.json() as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };
      return { provider, model: 'gemini-2.0-flash-lite', text: j.candidates?.[0]?.content?.parts?.[0]?.text || '' };
    }
    if (provider === 'cloudflare' && env.CLOUDFLARE_ACCOUNT_ID && env.CLOUDFLARE_API_TOKEN) {
      const res = await fetch(
        `https://api.cloudflare.com/client/v4/accounts/${env.CLOUDFLARE_ACCOUNT_ID}/ai/run/@cf/meta/llama-3.1-8b-instruct`,
        {
          method: 'POST',
          headers: { Authorization: `Bearer ${env.CLOUDFLARE_API_TOKEN}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages, max_tokens: 1024 }),
        },
      );
      if (!res.ok) return { provider, model: 'llama-3.1-8b', text: '', error: await res.text() };
      const j = await res.json() as { result?: { response?: string } };
      return { provider, model: '@cf/meta/llama-3.1-8b-instruct', text: j.result?.response || '' };
    }
  } catch (e) {
    return { provider, model: '', text: '', error: String(e) };
  }
  return { provider, model: '', text: '', error: 'not configured' };
}

councilRoutes.post('/compare', async (c) => {
  const auth = c.req.header('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return c.json({ error: 'unauthorized' }, 401);
  const body = await c.req.json().catch(() => null) as { messages?: Msg[]; privateMode?: boolean; providers?: string[] } | null;
  if (!body?.messages?.length) return c.json({ error: 'messages required' }, 400);
  const env = c.env as Record<string, string | undefined>;
  const want = body.providers || ['groq', 'gemini', 'cloudflare'];
  const pool = body.privateMode ? want.filter((p) => p === 'groq' || p === 'cloudflare' || p === 'local') : want;
  const results = await Promise.all(pool.map((p) => callProvider(env, p, body.messages!)));
  return c.json({ results, count: results.length });
});

councilRoutes.post('/council', async (c) => {
  const auth = c.req.header('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return c.json({ error: 'unauthorized' }, 401);
  const body = await c.req.json().catch(() => null) as { messages?: Msg[]; privateMode?: boolean } | null;
  if (!body?.messages?.length) return c.json({ error: 'messages required' }, 400);
  const env = c.env as Record<string, string | undefined>;
  const providers = body.privateMode ? ['groq', 'cloudflare'] : ['groq', 'gemini', 'cloudflare'];
  return streamSSE(c, async (stream) => {
    await stream.writeSSE({ data: JSON.stringify({ type: 'phase', phase: 'fanout' }) });
    const results = await Promise.all(providers.map((p) => callProvider(env, p, body.messages!)));
    for (const r of results) {
      await stream.writeSSE({ data: JSON.stringify({ type: 'member', provider: r.provider, model: r.model, text: r.text.slice(0, 2000), error: r.error }) });
    }
    const good = results.filter((r) => r.text && !r.error);
    const preferred = good.find((r) => r.provider === 'groq' || r.provider === 'cloudflare') || good[0];
    if (!preferred) {
      await stream.writeSSE({ data: JSON.stringify({ type: 'error', message: 'all council members failed' }) });
      return;
    }
    await stream.writeSSE({ data: JSON.stringify({ type: 'phase', phase: 'synthesize' }) });
    for (const word of preferred.text.split(/(\s+)/)) {
      await stream.writeSSE({ data: JSON.stringify({ type: 'delta', text: word }) });
    }
    await stream.writeSSE({ data: JSON.stringify({ type: 'done', synthesizer: preferred.provider, members: results.map((r) => r.provider) }) });
  });
});
