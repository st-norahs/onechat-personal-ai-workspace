import { Hono } from 'hono';
import { streamSSE } from 'hono/streaming';

export const chatRoutes = new Hono();

chatRoutes.post('/stream', async (c) => {
  const auth = c.req.header('Authorization') || '';
  if (!auth.startsWith('Bearer ')) {
    return c.json({ error: 'unauthorized' }, 401);
  }

  const body = await c.req.json().catch(() => null) as {
    messages?: Array<{ role: string; content: string }>;
    privateMode?: boolean;
  } | null;

  if (!body?.messages?.length) {
    return c.json({ error: 'messages required' }, 400);
  }

  const env = c.env as Record<string, string | undefined>;
  const privateMode = !!body.privateMode;

  type Candidate = { id: string; provider: string; data_policy: string; url: string; headers: Record<string, string>; body: unknown };
  const candidates: Candidate[] = [];

  candidates.push({
    id: 'local-fallback',
    provider: 'local',
    data_policy: 'no_train',
    url: '',
    headers: {},
    body: null,
  });

  if (env.GROQ_API_KEY) {
    candidates.unshift({
      id: 'openai/gpt-oss-20b',
      provider: 'groq',
      data_policy: 'no_train',
      url: 'https://api.groq.com/openai/v1/chat/completions',
      headers: {
        Authorization: `Bearer ${env.GROQ_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: {
        model: 'openai/gpt-oss-20b',
        messages: body.messages,
        stream: true,
        max_tokens: 2048,
      },
    });
  }

  if (env.GEMINI_API_KEY && !privateMode) {
    candidates.push({
      id: 'gemini-2.0-flash-lite',
      provider: 'gemini',
      data_policy: 'may_train',
      url: `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:streamGenerateContent?alt=sse&key=${env.GEMINI_API_KEY}`,
      headers: { 'Content-Type': 'application/json' },
      body: {
        contents: body.messages
          .filter((m) => m.role !== 'system')
          .map((m) => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: m.content }],
          })),
        generationConfig: { maxOutputTokens: 2048 },
      },
    });
  }

  if (env.CLOUDFLARE_ACCOUNT_ID && env.CLOUDFLARE_API_TOKEN) {
    candidates.unshift({
      id: '@cf/meta/llama-3.1-8b-instruct',
      provider: 'cloudflare',
      data_policy: 'no_train',
      url: `https://api.cloudflare.com/client/v4/accounts/${env.CLOUDFLARE_ACCOUNT_ID}/ai/run/@cf/meta/llama-3.1-8b-instruct`,
      headers: {
        Authorization: `Bearer ${env.CLOUDFLARE_API_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: {
        messages: body.messages,
        stream: true,
        max_tokens: 1024,
      },
    });
  }

  const pool = privateMode
    ? candidates.filter((x) => x.data_policy === 'no_train')
    : candidates;

  const pick = pool[0];
  if (!pick) {
    return c.json({ error: 'no eligible model' }, 503);
  }

  return streamSSE(c, async (stream) => {
    await stream.writeSSE({
      data: JSON.stringify({
        type: 'meta',
        model: pick.id,
        reason: privateMode ? 'private mode → no_train' : `best available free (${pick.provider})`,
      }),
    });

    if (pick.provider === 'local') {
      const last = body.messages!.filter((m) => m.role === 'user').pop()?.content || '';
      const reply =
        `[Local fallback]\nReceived: "${last.slice(0, 100)}"\n\nNo cloud key available or Private mode with no no_train provider. Configure GROQ_API_KEY or CLOUDFLARE_* for free cloud inference.`;
      for (const word of reply.split(/(\s+)/)) {
        await stream.writeSSE({ data: JSON.stringify({ type: 'delta', text: word }) });
      }
      await stream.writeSSE({ data: JSON.stringify({ type: 'done' }) });
      return;
    }

    try {
      const res = await fetch(pick.url, {
        method: 'POST',
        headers: pick.headers,
        body: JSON.stringify(pick.body),
      });

      if (!res.ok) {
        const err = await res.text();
        await stream.writeSSE({
          data: JSON.stringify({ type: 'error', message: `${pick.provider} ${res.status}: ${err.slice(0, 200)}` }),
        });
        return;
      }

      const reader = res.body?.getReader();
      if (!reader) {
        await stream.writeSSE({ data: JSON.stringify({ type: 'error', message: 'no body' }) });
        return;
      }
      const dec = new TextDecoder();
      let buf = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n');
        buf = lines.pop() || '';
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const raw = line.slice(6).trim();
          if (!raw || raw === '[DONE]') continue;
          try {
            const json = JSON.parse(raw);
            let text = '';
            if (pick.provider === 'groq' || pick.provider === 'openrouter') {
              text = json?.choices?.[0]?.delta?.content || '';
            } else if (pick.provider === 'gemini') {
              text = json?.candidates?.[0]?.content?.parts?.[0]?.text || '';
            } else if (pick.provider === 'cloudflare') {
              text = json?.response || json?.choices?.[0]?.delta?.content || '';
            }
            if (text) {
              await stream.writeSSE({ data: JSON.stringify({ type: 'delta', text }) });
            }
          } catch { /* skip */ }
        }
      }
      await stream.writeSSE({ data: JSON.stringify({ type: 'done' }) });
    } catch (e) {
      await stream.writeSSE({
        data: JSON.stringify({ type: 'error', message: String(e) }),
      });
    }
  });
});
