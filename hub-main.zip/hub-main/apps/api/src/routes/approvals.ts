import { Hono } from 'hono';
import { z } from 'zod';

const ApprovalRequest = z.object({
  action: z.enum(['drive_write', 'email_send', 'calendar_create', 'browser_navigate', 'custom']),
  payload: z.record(z.unknown()),
  rationale: z.string().max(2000).optional(),
  risk: z.enum(['low', 'medium', 'high']).default('medium'),
});

export const approvalRoutes = new Hono();

approvalRoutes.post('/queue', async (c) => {
  const auth = c.req.header('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return c.json({ error: 'unauthorized' }, 401);
  const body = await c.req.json().catch(() => null);
  const parsed = ApprovalRequest.safeParse(body);
  if (!parsed.success) return c.json({ error: 'invalid', details: parsed.error.flatten() }, 400);
  const id = crypto.randomUUID();
  const now = Date.now();
  try {
    await c.env.DB.prepare(`CREATE TABLE IF NOT EXISTS approvals (id TEXT PRIMARY KEY, action TEXT, payload TEXT, rationale TEXT, risk TEXT, status TEXT, created_at INTEGER, decided_at INTEGER, decided_by TEXT)`).run();
    await c.env.DB.prepare(`INSERT INTO approvals (id, action, payload, rationale, risk, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', ?)`).bind(id, parsed.data.action, JSON.stringify(parsed.data.payload), parsed.data.rationale || '', parsed.data.risk, now).run();
  } catch (e) { console.error(e); }
  return c.json({ id, status: 'pending' }, 201);
});

approvalRoutes.get('/pending', async (c) => {
  const auth = c.req.header('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return c.json({ error: 'unauthorized' }, 401);
  try {
    const { results } = await c.env.DB.prepare(`SELECT id, action, payload, rationale, risk, status, created_at FROM approvals WHERE status = 'pending' ORDER BY created_at DESC LIMIT 50`).all();
    return c.json({ items: (results || []).map((r: Record<string, unknown>) => ({ ...r, payload: typeof r.payload === 'string' ? JSON.parse(r.payload as string) : r.payload })) });
  } catch { return c.json({ items: [] }); }
});

approvalRoutes.post('/:id/decide', async (c) => {
  const auth = c.req.header('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return c.json({ error: 'unauthorized' }, 401);
  const id = c.req.param('id');
  const body = await c.req.json().catch(() => null) as { decision?: string } | null;
  if (!body?.decision || !['approve', 'reject'].includes(body.decision)) return c.json({ error: 'decision must be approve|reject' }, 400);
  const status = body.decision === 'approve' ? 'approved' : 'rejected';
  try {
    await c.env.DB.prepare(`UPDATE approvals SET status = ?, decided_at = ?, decided_by = 'owner' WHERE id = ? AND status = 'pending'`).bind(status, Date.now(), id).run();
    await c.env.DB.prepare(`CREATE TABLE IF NOT EXISTS audit_log (id TEXT PRIMARY KEY, event TEXT, detail TEXT, at INTEGER)`).run();
    await c.env.DB.prepare(`INSERT INTO audit_log (id, event, detail, at) VALUES (?, ?, ?, ?)`).bind(crypto.randomUUID(), `approval_${status}`, id, Date.now()).run();
  } catch (e) { return c.json({ error: 'persist failed' }, 500); }
  return c.json({ id, status });
});
