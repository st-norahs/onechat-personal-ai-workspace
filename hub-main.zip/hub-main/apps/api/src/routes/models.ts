import { Hono } from 'hono';

export const modelRoutes = new Hono();

const SEED_REGISTRY = [
  { id: 'openai/gpt-oss-20b', provider: 'groq', status: 'active', cost_class: 'free', data_policy: 'no_train', caps: ['chat', 'code', 'json'], scores: { chat: 0.72, code: 0.75 }, latencyP50: 200, quota: { rpm: 30, rpd: 1000, tpm: 8000, tpd: 200000 }, version: '2026-10' },
  { id: 'qwen/qwen3.8-27b', provider: 'groq', status: 'active', cost_class: 'free', data_policy: 'no_train', caps: ['chat', 'code'], scores: { chat: 0.78, code: 0.8 }, latencyP50: 250, quota: { rpm: 30, rpd: 1000 }, version: '2026-10' },
  { id: 'gemini-2.0-flash-lite', provider: 'gemini', status: 'active', cost_class: 'free', data_policy: 'may_train', caps: ['chat', 'code', 'vision', 'json'], scores: { chat: 0.75, code: 0.7 }, latencyP50: 400, quota: { rpm: 15, rpd: 500 }, version: '2026-10' },
  { id: '@cf/meta/llama-3.1-8b-instruct', provider: 'cloudflare', status: 'active', cost_class: 'free', data_policy: 'no_train', caps: ['chat', 'code'], scores: { chat: 0.68 }, latencyP50: 600, quota: { rpd: 100 }, version: '2026-10' },
  { id: 'webllm-phi-3-mini', provider: 'local', status: 'active', cost_class: 'free', data_policy: 'no_train', caps: ['chat'], scores: { chat: 0.4 }, latencyP50: 2000, version: 'local' },
];

modelRoutes.get('/registry', async (c) => {
  try {
    const { results } = await c.env.DB.prepare(`SELECT data FROM registry_cache WHERE id = 'main' LIMIT 1`).all();
    if (results?.length) return c.json(JSON.parse((results[0] as { data: string }).data));
  } catch {}
  return c.json({ models: SEED_REGISTRY, updated_at: Date.now(), source: 'seed' });
});

modelRoutes.get('/leaderboard', (c) => {
  const task = c.req.query('task') || 'chat';
  const ranked = [...SEED_REGISTRY].filter((m) => m.status === 'active' && m.cost_class === 'free').sort((a, b) => (b.scores?.[task] ?? 0) - (a.scores?.[task] ?? 0));
  return c.json({ task, ranked });
});

modelRoutes.post('/promote', async (c) => {
  const auth = c.req.header('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return c.json({ error: 'unauthorized' }, 401);
  const body = await c.req.json().catch(() => null) as { modelId?: string; action?: string } | null;
  if (!body?.modelId || !body?.action) return c.json({ error: 'modelId and action required' }, 400);
  try {
    await c.env.DB.prepare(`CREATE TABLE IF NOT EXISTS promotion_log (id TEXT PRIMARY KEY, model_id TEXT, action TEXT, at INTEGER, actor TEXT)`).run();
    await c.env.DB.prepare(`INSERT INTO promotion_log (id, model_id, action, at, actor) VALUES (?, ?, ?, ?, 'owner')`).bind(crypto.randomUUID(), body.modelId, body.action, Date.now()).run();
  } catch {}
  return c.json({ ok: true, modelId: body.modelId, action: body.action });
});

modelRoutes.get('/quotas', async (c) => {
  const out: Record<string, unknown> = {};
  for (const m of SEED_REGISTRY.filter((m) => m.quota)) {
    try {
      const id = c.env.QUOTA.idFromName(m.id);
      const stub = c.env.QUOTA.get(id);
      const res = await stub.fetch('https://do/remaining', { method: 'POST', body: JSON.stringify({ key: m.id, quota: m.quota }) });
      out[m.id] = await res.json();
    } catch { out[m.id] = { error: 'unavailable' }; }
  }
  return c.json({ quotas: out });
});
