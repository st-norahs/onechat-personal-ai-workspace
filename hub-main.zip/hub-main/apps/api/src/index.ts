import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { secureHeaders } from 'hono/secure-headers';
import { authRoutes } from './routes/auth';
import { healthRoutes } from './routes/health';
import { chatRoutes } from './routes/chat';
import { councilRoutes } from './routes/council';
import { approvalRoutes } from './routes/approvals';
import { modelRoutes } from './routes/models';
import { QuotaDO } from './quota-do';

export { QuotaDO };

type Env = {
  GOOGLE_CLIENT_ID: string;
  GOOGLE_CLIENT_SECRET: string;
  ALLOWED_EMAIL: string;
  JWT_SECRET: string;
  GEMINI_API_KEY?: string;
  GROQ_API_KEY?: string;
  OPENROUTER_API_KEY?: string;
  MISTRAL_API_KEY?: string;
  CLOUDFLARE_API_TOKEN?: string;
  CLOUDFLARE_ACCOUNT_ID?: string;
  MULTI_USER: string;
  AUTO_PROMOTE: string;
  EVAL_REQUEST_SHARE: string;
  QUOTA: DurableObjectNamespace;
  DB: D1Database;
  OPENAI_API_KEY?: string;
  ANTHROPIC_API_KEY?: string;
  XAI_API_KEY?: string;
  DEEPSEEK_API_KEY?: string;
  PERPLEXITY_API_KEY?: string;
  ENABLE_OPENAI?: string;
  ENABLE_ANTHROPIC?: string;
  ENABLE_XAI?: string;
  ENABLE_DEEPSEEK?: string;
  ENABLE_PERPLEXITY?: string;
};

const app = new Hono<{ Bindings: Env }>();

app.use('*', secureHeaders({
  contentSecurityPolicy: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'"],
    connectSrc: ["'self'", "https://accounts.google.com", "https://www.googleapis.com"],
    frameSrc: ["'none'"],
    objectSrc: ["'none'"],
  },
}));

app.use('*', cors({
  origin: (origin) => {
    if (!origin) return '';
    if (origin.endsWith('.pages.dev') || origin.includes('localhost')) return origin;
    return '';
  },
  allowMethods: ['GET', 'POST', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
  maxAge: 600,
}));

app.route('/health', healthRoutes);
app.route('/auth', authRoutes);
app.route('/chat', chatRoutes);
app.route('/council', councilRoutes);
app.route('/approvals', approvalRoutes);
app.route('/models', modelRoutes);

app.get('/', (c) => c.json({ name: 'Hub API', version: '0.1.0', status: 'ok' }));

app.notFound((c) => c.json({ error: 'not found' }, 404));
app.onError((err, c) => {
  console.error(err);
  return c.json({ error: 'internal' }, 500);
});

export default app;
