import {
  PBKDF2_ITERATIONS,
  newSalt,
  deriveKey,
  encryptRecord,
  decryptRecord,
  toB64,
  fromB64,
} from '@hub/shared';

const META_KEY = 'hub.crypto.meta';

export interface CryptoMeta {
  salt: string;
  iterations: number;
  check: { v: number; iv: string; ct: string };
}

export async function setupPassphrase(passphrase: string): Promise<CryptoMeta> {
  const salt = newSalt();
  const key = await deriveKey(passphrase, salt, PBKDF2_ITERATIONS);
  const check = await encryptRecord(key, { ok: true }, 'key-check');
  const meta: CryptoMeta = {
    salt: toB64(salt),
    iterations: PBKDF2_ITERATIONS,
    check,
  };
  localStorage.setItem(META_KEY, JSON.stringify(meta));
  return meta;
}

export async function unlock(passphrase: string): Promise<CryptoKey> {
  const raw = localStorage.getItem(META_KEY);
  if (!raw) throw new Error('No crypto meta — run setup first');
  const meta = JSON.parse(raw) as CryptoMeta;
  if (meta.iterations < PBKDF2_ITERATIONS) throw new Error('KDF iterations below minimum');
  const key = await deriveKey(passphrase, fromB64(meta.salt), meta.iterations);
  try {
    const pt = await decryptRecord(key, meta.check, 'key-check');
    if (!(pt as { ok?: boolean }).ok) throw new Error('bad check');
  } catch {
    throw new Error('Wrong passphrase');
  }
  return key;
}

export { encryptRecord, decryptRecord, newSalt, deriveKey, PBKDF2_ITERATIONS };
