const KEY = 'hub.session';

export interface Session {
  hubToken: string;
  email: string;
  googleAccess?: string;
  googleRefresh?: string;
  unlocked?: boolean;
}

export function getSession(): Session | null {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setSession(s: Session) {
  localStorage.setItem(KEY, JSON.stringify(s));
}

export function clearSession() {
  localStorage.removeItem(KEY);
}
