import { useState, useEffect } from 'react';
import { AuthScreen } from './components/AuthScreen';
import { UnlockScreen } from './components/UnlockScreen';
import { ChatShell } from './components/ChatShell';
import { ModelLab } from './components/ModelLab';
import { CompareView } from './components/CompareView';
import { getSession } from './lib/session';

type Phase = 'loading' | 'auth' | 'unlock' | 'ready';
type View = 'chat' | 'lab' | 'compare';

export function App() {
  const [phase, setPhase] = useState<Phase>('loading');
  const [view, setView] = useState<View>('chat');

  useEffect(() => {
    const s = getSession();
    if (!s?.hubToken) { setPhase('auth'); return; }
    if (!s.unlocked) { setPhase('unlock'); return; }
    setPhase('ready');
  }, []);

  if (phase === 'loading') return <div className="card muted">Loading…</div>;
  if (phase === 'auth') return <AuthScreen onDone={() => setPhase('unlock')} />;
  if (phase === 'unlock') return <UnlockScreen onDone={() => setPhase('ready')} />;

  if (view === 'lab') return <ModelLab onBack={() => setView('chat')} />;
  if (view === 'compare') return <CompareView onBack={() => setView('chat')} />;

  return (
    <>
      <div style={{ position: 'fixed', bottom: 72, right: 16, zIndex: 50, display: 'flex', flexDirection: 'column', gap: 8 }}>
        <button style={{ padding: '0.4rem 0.8rem', fontSize: '0.8rem' }} onClick={() => setView('lab')}>Model Lab</button>
        <button style={{ padding: '0.4rem 0.8rem', fontSize: '0.8rem' }} onClick={() => setView('compare')}>Compare</button>
      </div>
      <ChatShell />
    </>
  );
}
