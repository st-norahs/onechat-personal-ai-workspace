import { useState } from 'react';
import { setupPassphrase, unlock } from '../lib/crypto';
import { getSession, setSession } from '../lib/session';

export function UnlockScreen({ onDone }: { onDone: () => void }) {
  const [pass, setPass] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const hasMeta = !!localStorage.getItem('hub.crypto.meta');

  async function handle() {
    setBusy(true);
    setError('');
    try {
      if (!hasMeta) {
        if (pass.length < 12) throw new Error('Passphrase must be at least 12 characters');\n        if (pass !== confirm) throw new Error('Passphrases do not match');
        await setupPassphrase(pass);
        const recovery = btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(32))));
        alert('RECOVERY KEY (save offline, shown once):\n\n' + recovery);
      } else {
        await unlock(pass);
      }
      const s = getSession();
      if (s) setSession({ ...s, unlocked: true });
      onDone();
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="card">
      <h1>{hasMeta ? 'Unlock' : 'Create passphrase'}</h1>
      <p className="muted">
        {hasMeta
          ? 'Enter the passphrase that encrypts your Drive data.'
          : 'Choose a strong passphrase. A recovery key will be shown once.'}
      </p>
      <input
        type="password"
        placeholder="Passphrase"
        value={pass}
        onChange={(e) => setPass(e.target.value)}
        autoFocus
      />
      {!hasMeta && (
        <input
          type="password"
          placeholder="Confirm passphrase"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          style={{ marginTop: '0.5rem' }}
        />
      )}
      <button onClick={handle} disabled={busy || !pass} style={{ marginTop: '1rem' }}>
        {busy ? 'Working...' : hasMeta ? 'Unlock' : 'Create & unlock'}
      </button>
      {error && <p className="error">{error}</p>}
    </div>
  );
}
