import { getSession, clearSession } from '../lib/session';

export function ChatShell() {
  const s = getSession();
  return (
    <div style={{ padding: '1.5rem', maxWidth: 800, margin: '0 auto' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Hub</h1>
        <div className="muted">
          {s?.email}
          <button
            style={{ marginLeft: '1rem', background: '#334155', color: '#e2e8f0' }}
            onClick={() => { clearSession(); window.location.reload(); }}
          >
            Sign out
          </button>
        </div>
      </header>
      <p className="muted">
        Phase 1 skeleton ready. Chat, providers, and Drive sync land in Phase 2+.
      </p>
      <div className="card" style={{ marginTop: '2rem' }}>
        <p>Encrypted client-side storage is unlocked.</p>
        <p className="muted">Quota DO, D1 audit log, and OAuth allowlist are active on the Worker.</p>
      </div>
    </div>
  );
}
