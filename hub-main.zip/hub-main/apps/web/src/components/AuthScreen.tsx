import { useState } from 'react';
import { setSession } from '../lib/session';

const API = import.meta.env.VITE_API_URL || 'http://localhost:8787';

function generateVerifier(): string {
  const arr = new Uint8Array(32);
  crypto.getRandomValues(arr);
  return btoa(String.fromCharCode(...arr)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

async function sha256(verifier: string): Promise<string> {
  const data = new TextEncoder().encode(verifier);
  const hash = await crypto.subtle.digest('SHA-256', data);
  return btoa(String.fromCharCode(...new Uint8Array(hash)))
    .replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

export function AuthScreen({ onDone }: { onDone: () => void }) {
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function startLogin() {
    setBusy(true);
    setError('');
    try {
      const cfgRes = await fetch(`${API}/auth/config`);
      if (!cfgRes.ok) throw new Error('API not reachable');
      const cfg = await cfgRes.json() as { client_id: string; scopes: string[] };

      const verifier = generateVerifier();
      sessionStorage.setItem('pkce_verifier', verifier);
      const challenge = await sha256(verifier);
      const redirect = window.location.origin + '/auth/callback';

      const params = new URLSearchParams({
        client_id: cfg.client_id,
        redirect_uri: redirect,
        response_type: 'code',
        scope: cfg.scopes.join(' '),
        code_challenge: challenge,
        code_challenge_method: 'S256',
        access_type: 'offline',
        prompt: 'consent',
      });
      window.location.href = `https://accounts.google.com/o/oauth2/v2/auth?${params}`;
    } catch (e) {
      setError(String(e));
      setBusy(false);
    }
  }

  useState(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    if (!code) return;
    (async () => {
      setBusy(true);
      try {
        const verifier = sessionStorage.getItem('pkce_verifier') || '';
        const redirect = window.location.origin + '/auth/callback';
        const res = await fetch(`${API}/auth/token`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code, code_verifier: verifier, redirect_uri: redirect }),
        });
        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          throw new Error((err as { error?: string }).error || 'auth failed');
        }
        const data = await res.json() as {
          hub_token: string;
          google: { access_token: string; refresh_token?: string };
        };
        const payload = JSON.parse(atob(data.hub_token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
        setSession({
          hubToken: data.hub_token,
          email: payload.email,
          googleAccess: data.google.access_token,
          googleRefresh: data.google.refresh_token,
        });
        window.history.replaceState({}, '', '/');
        onDone();
      } catch (e) {
        setError(String(e));
        setBusy(false);
      }
    })();
  });

  return (
    <div className="card">
      <h1>Hub</h1>
      <p className="muted">Private multi-model AI assistant. Zero cost.</p>
      <button onClick={startLogin} disabled={busy}>
        {busy ? 'Signing in…' : 'Sign in with Google'}
      </button>
      {error && <p className="error">{error}</p>}
    </div>
  );
}
