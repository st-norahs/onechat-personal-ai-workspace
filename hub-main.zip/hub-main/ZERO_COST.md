# ZERO_COST.md — Hub Free-Tier Audit

Verified: 2026-10-04. All services used by Hub must stay at $0/month. Limits are stored in `providers.json` (not hard-coded) with source URL + verified_at. Runtime always honors provider rate-limit headers and 429s. Exceeding a free ceiling fails closed (no silent billing).

## 1. Cloudflare Workers (Backend + Durable Objects + D1)

| Resource | Free limit | Source | What happens at ceiling |
|----------|------------|--------|-------------------------|
| Requests | 100,000 / day | [Workers pricing](https://developers.cloudflare.com/workers/platform/pricing/) | Further requests fail |
| CPU time | 10 ms / invocation | same | Hard kill |
| Subrequests | 50 / request | [Workers limits](https://developers.cloudflare.com/workers/platform/limits/) | Fail |
| KV reads | 100,000 / day | [KV pricing](https://developers.cloudflare.com/kv/platform/pricing/) | Fail |
| KV writes / deletes / lists | 1,000 / day | same | Fail |
| Durable Objects (SQLite) requests | 100,000 / day | [DO pricing](https://developers.cloudflare.com/durable-objects/platform/pricing/) | Fail |
| DO storage | 5 GB total | same | Fail |
| DO classes | 100 | [DO limits](https://developers.cloudflare.com/durable-objects/platform/limits/) | Fail |
| D1 rows read | 5 million / day | [D1 pricing](https://developers.cloudflare.com/d1/platform/pricing/) | Fail |
| D1 rows written | 100,000 / day | same | Fail |
| D1 storage | 5 GB total | same | Fail |
| D1 databases | 10 (Free) | [D1 limits](https://developers.cloudflare.com/d1/platform/limits/) | Fail |

Design consequence: Worker stays thin (auth, quota check, stream proxy). No heavy CPU, no KV for hot-path counters. Quota + session state live in SQLite-backed Durable Objects. Audit log + registry cache in D1.

## 2. Cloudflare Pages (Frontend PWA)

| Resource | Free limit | Source | What happens at ceiling |
|----------|------------|--------|-------------------------|
| Static asset requests | Unlimited | [Pages pricing](https://developers.cloudflare.com/pages/functions/pricing/) | N/A |
| Builds | 500 / month, 1 concurrent | [Pages limits](https://developers.cloudflare.com/pages/platform/limits/) | Queue / fail |
| Files per site | 20,000 | same | Reject deploy |
| Single file size | 25 MiB | same | Reject |
| Custom domains | 100 | same | Fail |
| Functions requests | Count against Workers 100k/day | same | Fail |

## 3. Cloudflare Workers AI

| Resource | Free limit | Source | What happens at ceiling |
|----------|------------|--------|-------------------------|
| Neurons | 10,000 / day (resets 00:00 UTC) | [Workers AI pricing](https://developers.cloudflare.com/workers-ai/platform/pricing/) | Error 3036 / 429 |
| Text generation RPM | 300 (default; paid models 20) | [Workers AI limits](https://developers.cloudflare.com/workers-ai/platform/limits/) | 429 |
| Card required | No (until you exceed daily Neurons) | same | — |

Neuron cost varies by model; large models exhaust the pool faster. Free plan fails closed; no silent billing.

## 4. Google Gemini API (Free Tier)

| Resource | Free limit (as of 2026-10) | Source | What happens at ceiling |
|----------|----------------------------|--------|-------------------------|
| Model access | Flash-Lite class only after 2026-10-09; exact RPD/RPM/TPM shown per-project in AI Studio | [Gemini pricing](https://ai.google.dev/gemini-api/docs/pricing), [AI Studio](https://aistudio.google.com) | 429 |
| Grounding (Search/Maps) | 500 RPD shared (older models); 5,000/month (Gemini 3.x) | same | 429 / paid |
| Card required | No | same | — |
| Data policy | may_train (free tier content may be used to improve products) | pricing page | — |

Exact RPM/TPM/RPD are project-specific and not published as fixed public numbers. Hub reads them at runtime from response headers / AI Studio and stores the verified values in `providers.json`.

## 5. Groq API (Free Plan)

| Resource | Free limit (sample; authoritative in console) | Source | What happens at ceiling |
|----------|-----------------------------------------------|--------|-------------------------|
| openai/gpt-oss-120b, gpt-oss-20b, qwen/qwen3.8-27b | 30 RPM / 1,000 RPD / 8K TPM / 200K TPD | [Groq rate limits](https://console.groq.com/docs/rate-limits) | 429 |
| Other models | Vary (see console Limits page) | same | 429 |
| Card required | No | same | — |

Limits are per-organization. Exact values live on the account Limits page; Hub reads rate-limit headers on every response.

## 6. OpenRouter (`:free` models only)

| Resource | Free limit | Source | What happens at ceiling |
|----------|------------|--------|-------------------------|
| Requests | 20 RPM; 50 RPD (until $10 lifetime credits purchased → 1,000 RPD) | [OpenRouter rate limits](https://openrouter.zendesk.com/hc/en-us/articles/39501163636379-OpenRouter-Rate-Limits-What-You-Need-to-Know) | 429 / 402 |
| Pricing filter | Model ID must end in `:free` AND every price field must be exactly zero | code + catalog | Reject non-free |
| Card required | No | same | — |

Hub rejects any model that fails `assertFreeOpenRouter`. Negative balance returns 402 even on free models.

## 7. Mistral AI (La Plateforme Free / Experiment mode)

| Resource | Free limit | Source | What happens at ceiling |
|----------|------------|--------|-------------------------|
| Access | Free evaluation tier; exact RPM/TPM shown only in Admin → Limits | [Mistral help / console](https://mistral.ai) | 429 |
| Card required | No (phone verification) | same | — |
| Data policy | may_train by default; opt-out available in Admin | same | — |

Exact numbers are unpublished; Hub stores the console values in `providers.json` at setup time.

## 8. Google Drive API (appDataFolder + weekly backup)

| Resource | Free limit | Source | What happens at ceiling |
|----------|------------|--------|-------------------------|
| Queries | 12,000 / 60 s (per project + per user) | [Drive limits](https://developers.google.com/drive/api/guides/limits) | 429 |
| Storage | User’s personal Drive quota (no extra charge for API) | same | Fail |
| Scopes used | `drive.appdata` (core), `drive.file` (weekly encrypted backup only) | [appdata guide](https://developers.google.com/workspace/drive/api/guides/appdata) | — |
| Card required | No | same | — |

appDataFolder is deleted if the user revokes the app; weekly encrypted backup to a visible folder + local export mitigate data loss.

## 9. Google OAuth (OIDC + PKCE)

| Resource | Free limit | Source | What happens at ceiling |
|----------|------------|--------|-------------------------|
| Consent screen | Must be set to “In production” (Testing mode refresh tokens expire after 7 days) | Google Cloud Console | — |
| Scopes | openid, email, drive.appdata (core); Gmail/Calendar optional modules | same | — |
| Card required | No | same | — |

## 10. GitHub Actions (CI + Scouts + Playwright)

| Resource | Free limit (personal account) | Source | What happens at ceiling |
|----------|-------------------------------|--------|-------------------------|
| Minutes | 2,000 / month (Linux) | GitHub docs | Jobs fail / queue |
| Storage | 500 MB | same | Fail |
| Concurrent jobs | Limited | same | Queue |

Scout workflows run daily on `workflow_dispatch` / schedule; Playwright approval-queue jobs are triggered only by owner.

## 11. On-device (WebLLM / WebGPU)

| Resource | Free limit | Source | What happens at ceiling |
|----------|------------|--------|-------------------------|
| Compute | User’s device | WebLLM | N/A (local) |
| Data policy | no_train | — | — |

Always available as private fallback; no network, no quota, no key.

## 12. Explicitly Disabled (Tier B)

OpenAI, Anthropic, xAI (Grok), DeepSeek, Perplexity — shipped as adapters but **DISABLED** (`ENABLE_<PROVIDER>=false`). A call is impossible unless both the flag is true and the key exists. No free recurring API tier exists for these providers as of 2026-10-04.

## Design Rules Enforced by Code

1. Every price field must be present and strictly zero → `classifyCost` / `assertFreeOpenRouter`.
2. Tier-B providers require both `ENABLE_*=true` and a non-empty key → `assertCallable`.
3. Sensitive content routes only to `no_train` or local models.
4. Quota counters live in Durable Objects; Worker never does heavy work.
5. All limits re-verified at setup (`pnpm doctor`) and stored with `verified_at` + source URL.
6. Exceeding any free ceiling fails closed; no silent paid fallback.
