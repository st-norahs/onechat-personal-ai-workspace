#!/usr/bin/env node
import { assertCallable, assertFreeOpenRouter, classifyCost } from '../packages/shared/src/core.mjs';

const env = process.env;
const results = [];

function check(name, fn) {
  try { fn(); results.push({ name, status: 'pass' }); }
  catch (e) { results.push({ name, status: 'fail', error: String(e.message || e) }); }
}

for (const p of ['openai', 'anthropic', 'xai', 'deepseek', 'perplexity']) {
  check(`tierB-blocked-${p}`, () => {
    try { assertCallable(p, env); throw new Error('should have thrown'); }
    catch (e) { if (String(e.message).includes('should have thrown')) throw e; }
  });
}

check('openrouter-free-guard', () => {
  assertFreeOpenRouter({ id: 'x/y:free', pricing: { prompt: '0', completion: '0' } });
  try { assertFreeOpenRouter({ id: 'x/y', pricing: { prompt: '0', completion: '0' } }); throw new Error('should reject non-:free'); }
  catch (e) { if (String(e.message).includes('should reject')) throw e; }
});

check('classifyCost-zero', () => {
  if (classifyCost({ prompt: '0', completion: '0' }) !== 'free') throw new Error('expected free');
  if (classifyCost({ prompt: '0.001', completion: '0' }) !== 'paid') throw new Error('expected paid');
});

async function probe(name, url, headers, body) {
  try {
    const res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body) });
    results.push({ name, status: res.ok ? 'pass' : 'fail', http: res.status });
  } catch (e) { results.push({ name, status: 'fail', error: String(e.message || e) }); }
}

if (env.GROQ_API_KEY) {
  await probe('groq-live', 'https://api.groq.com/openai/v1/chat/completions', {
    Authorization: `Bearer ${env.GROQ_API_KEY}`, 'Content-Type': 'application/json',
  }, { model: 'openai/gpt-oss-20b', messages: [{ role: 'user', content: 'hi' }], max_tokens: 1 });
} else results.push({ name: 'groq-live', status: 'disabled' });

if (env.GEMINI_API_KEY) {
  await probe('gemini-live',
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:generateContent?key=${env.GEMINI_API_KEY}`,
    { 'Content-Type': 'application/json' },
    { contents: [{ role: 'user', parts: [{ text: 'hi' }] }], generationConfig: { maxOutputTokens: 1 } });
} else results.push({ name: 'gemini-live', status: 'disabled' });

console.log(JSON.stringify(results, null, 2));
process.exit(results.some((r) => r.status === 'fail') ? 1 : 0);
