# ARCHITECTURE.md — Hub

## Stack
- **Frontend**: React + Vite + TypeScript PWA on Cloudflare Pages
- **Backend**: Cloudflare Worker (Hono + TypeScript) — sole holder of API keys
- **State**: Durable Objects (SQLite) for quota; D1 for audit + registry cache
- **Data**: Google Drive appDataFolder, client-side AES-GCM (PBKDF2 600k)
- **Models**: Free-tier only (Gemini Flash-Lite, Groq, OpenRouter `:free`, CF Workers AI, WebLLM)

## Request path
```
Browser (PWA)
  → JWT + messages
  → Worker (auth, killSwitch, quota check)
  → Provider stream proxy (egress allowlist)
  → SSE back to client
```

## Packages
| Package | Role |
|---------|------|
| `packages/shared` | Crypto, cost guards, router, promotion, quota tracker |
| `packages/providers` | Adapter interface + Gemini/Groq/OpenRouter/CF/Local |
| `packages/tools` | MCP client, fetch/search, Drive helpers |
| `apps/api` | Worker routes: auth, chat, council, approvals, models |
| `apps/web` | PWA UI: auth, unlock, chat, compare, model lab |

## Privacy tiers
- `no_train`: Groq, Cloudflare AI, local
- `may_train`: Gemini free tier
- Sensitive / Private mode → no_train or local only
