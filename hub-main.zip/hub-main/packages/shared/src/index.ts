// Re-export pure core logic (ESM) until full TS port is complete.
// All guards, crypto, quota, router, promotion must remain identical to core.mjs.
export * from './core.mjs';
