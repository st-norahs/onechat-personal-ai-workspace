export interface ChatMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
  name?: string;
}

export interface ModelInfo {
  id: string;
  provider: string;
  status: 'active' | 'canary' | 'candidate' | 'shadow' | 'deprecated' | 'blocked';
  cost_class: 'free' | 'credit' | 'paid';
  data_policy: 'no_train' | 'may_train' | 'unknown';
  caps: string[];
  scores?: Record<string, number>;
  latencyP50?: number;
  quota?: { rpm?: number; rpd?: number; tpm?: number; tpd?: number };
  canaryShare?: number;
}

export type StreamEvent =
  | { type: 'delta'; text: string }
  | { type: 'done'; usage?: { prompt: number; completion: number } }
  | { type: 'error'; message: string }
  | { type: 'tool_call'; id: string; name: string; args: string };

export interface StreamOpts {
  model: string;
  temperature?: number;
  maxTokens?: number;
  signal?: AbortSignal;
}

export interface ProviderAdapter {
  id: string;
  capabilities: string[];
  dataPolicy: 'no_train' | 'may_train' | 'unknown';
  listModels(): Promise<ModelInfo[]>;
  stream(messages: ChatMessage[], opts: StreamOpts): AsyncIterable<StreamEvent>;
}
